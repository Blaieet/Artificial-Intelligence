# -*- coding: utf-8 -*-
#
# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for 
# educational purposes provided that (1) you do not distribute or publish 
# solutions, (2) you retain this notice, and (3) you provide clear 
# attribution to UC Berkeley, including a link to 
# http://inst.eecs.berkeley.edu/~cs188/pacman/pacman.html
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero 
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and 
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    stack = util.Stack() #DFS s'implementa amb una pila
    visited = []

    startState = ()
    pos = problem.getStartState()
    moviment = []
    startState = (pos,moviment)

    stack.push(startState) 

    while not stack.isEmpty():
        actualState = stack.pop()
        actualPos = actualState[0]
        accumulatedMove = actualState[1]

        if problem.isGoalState(actualPos):
            return accumulatedMove

        if actualPos not in visited:
            visited.append(actualPos)
            successorsStates = problem.getSuccessors(actualPos)

            for i in successorsStates:
                successorPos = i[0]
                succesorAccumulatedMove = i[1]
                #Sumo els moviments que porto + els de cada posible succesor
                stack.push((i[0],accumulatedMove+[succesorAccumulatedMove]))

    return []




def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    queue = util.Queue() #BFS s'implementa amb una cua
    visited = []

    startState = ()
    pos = problem.getStartState()
    moviment = []
    startState = (pos,moviment)

    queue.push(startState)

    while not queue.isEmpty():
        actualState = queue.pop()
        actualPos = actualState[0]
        accumulatedMove = actualState[1]

        if problem.isGoalState(actualPos):
            return accumulatedMove

        if actualPos not in visited:
            visited.append(actualPos)
            successorsStates = problem.getSuccessors(actualPos)

            for i in successorsStates:
                successorPos = i[0]
                succesorAccumulatedMove = i[1]
                #El mateix que abans, concateno els moviments que porto + els de cada posible succesor
                queue.push((i[0],accumulatedMove+[succesorAccumulatedMove]))

    return []




def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    visitats = []
    aVisitar = util.PriorityQueue() #A* amb priorityQueue perque vull treue l'estat amb menys cost

    pos = problem.getStartState()
    moviment = []
    cost = 0

    estatInicial = (pos,moviment,cost)

    aVisitar.push(estatInicial,cost)

    while not aVisitar.isEmpty():
        estatActual = aVisitar.pop()
        posActual = estatActual[0]
        movimentsAcumulats = estatActual[1]

        if problem.isGoalState(posActual):
            return movimentsAcumulats

        if posActual not in visitats:
            visitats.append(posActual)
            costAccumulat = estatActual[2]
            succesors = problem.getSuccessors(posActual)
            for succesor in succesors:
                posSucc = succesor[0]
                movimentSucc, costSucc = succesor[1], succesor[2]
                h = heuristic(posSucc,problem) #Heuristica que s'em pasa per paramentre
                #Aqui concateno els moviments (accions) i tambe el cost, que sera l'acumulat, el del estat succesor i el de l'heuristica
                aVisitar.push((posSucc,movimentsAcumulats+[movimentSucc],costAccumulat+costSucc),costAccumulat+costSucc+h)
    return []



# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
