# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for 
# educational purposes provided that (1) you do not distribute or publish 
# solutions, (2) you retain this notice, and (3) you provide clear 
# attribution to UC Berkeley, including a link to 
# http://inst.eecs.berkeley.edu/~cs188/pacman/pacman.html
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero 
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and 
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        
        if successorGameState.isWin():
          return float('Inf')

        currentFoodList = currentGameState.getFood().asList() #El menjar en aquest moment
        newFoodList = newFood.asList() #El menjar que hi haura

        currentGhostsStates = currentGameState.getGhostStates() #Els estats dels fantasmes ara
        newGhostsStates = successorGameState.getGhostStates() #Els estats dels fantasmes despres
        currentGhostsPos = [i.getPosition() for i in currentGhostsStates] #Llista de les posicions dels fantasmes ara
        newGhostsPos = [i.getPosition() for i in newGhostStates] #I despres

        newDistMenjar = [util.manhattanDistance(newPos,i) for i in newFoodList] #Distancia del menjar despres
        currentDistGhosts = [util.manhattanDistance(newPos,i) for i in currentGhostsPos] #Distancia dels fantasmes ara
        newDistGhosts = [util.manhattanDistance(newPos,i) for i in newGhostsPos] #Distanciies als fantasmes despres

        #llista de menjar que falta ara i despres
        faltaraMenjar = len(newFoodList) 
        faltaMenjar = len(currentFoodList)

        #Numero de capsules a menjar
        capsulesRestants = len(successorGameState.getCapsules())

        #Temps que queda per a que els fantasmes estiguin espantats
        tempsRestantEspantats = sum(newScaredTimes)


        puntuacio = 0
        puntuacio += successorGameState.getScore() - currentGameState.getScore() #Puntuacio de despres v. la d'ara

        #Penalitzacio per quedarse quiet
        if action == Directions.STOP:
          puntuacio -= 100

        #Bonificacio si estas en un estat on hi ha una capsula
        if newPos in currentGameState.getCapsules():
          puntuacio += 150*capsulesRestants 

        #Bonificacio si menjes en comptes de "no menjar"
        if faltaMenjar > faltaraMenjar:
          puntuacio +=200

        #Penalitzacio per no menjar
        puntuacio -= 10 * faltaMenjar

        #Si els fantasmes estan espantats, guanyo puntuacio com mes a prop em trobi d'ells. Si no, resto.
        if tempsRestantEspantats > 0:
          if min(newDistGhosts) > min(currentDistGhosts):
            puntuacio += 200
          else:
            puntuacio -=200
        else:
          if min(newDistGhosts) > min(currentDistGhosts):
            puntuacio += 200 
          else:
            puntuacio -= 200

        return puntuacio

 
def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.

          Here are some method calls that might be useful when implementing minimax.

          gameState.getLegalActions(agentIndex):
            Returns a list of legal actions for an agent
            agentIndex=0 means Pacman, ghosts are >= 1

          gameState.generateSuccessor(agentIndex, action):
            Returns the successor game state after an agent takes an action

          gameState.getNumAgents():
            Returns the total number of agents in the game
        """
        "*** YOUR CODE HERE ***"

        #Funcio que retorna el maxValue d'un estat. El maximitzador sempre es Pacman, agent zero.
        def maximitzador(gameState,depth):
          novaProf = depth + 1

          if gameState.isWin() or gameState.isLose() or novaProf == self.depth:
            return self.evaluationFunction(gameState)

          maxim = float('-Inf') #Init

          accions = gameState.getLegalActions(0)

          for accio in accions:
            succesor = gameState.generateSuccessor(0,accio)
            maxim = max(maxim,minimitzador(succesor,novaProf,1)) #Agafa el maxim que pots trobar, el valor mes gran que et dona el minimitzador
          return maxim
        ##Funcio que retorna el minValue d'un estat (Els fantasmes nomes)
        def minimitzador(gameState,depth,agentIndex):
          minim = float('Inf')

          if gameState.isWin() or gameState.isLose():
            return self.evaluationFunction(gameState)

          accions = gameState.getLegalActions(agentIndex)

          for accio in accions:
            succesor = gameState.generateSuccessor(agentIndex,accio)

            if agentIndex == (gameState.getNumAgents() - 1): #Si em trobo analitzant l'ultim agent que existeix, el seguent sera pacman. Llavors, haig de cridar el maximitzador
              minim = min(minim,maximitzador(succesor,depth))
            else: #Si no, segueixo fent l'agent que vingui a continuacio i per tant es un minimitzador
              minim = min(minim,minimitzador(succesor,depth,agentIndex+1))
          return minim 

        #Accions necesaries per quan estem al root (pacman)
        accions = gameState.getLegalActions(0)

        score = float('-Inf')

        choosedAction = None

        for accio in accions:
          succesor = gameState.generateSuccessor(0,accio)

          scoreTemp = minimitzador(succesor,0,1)

          if scoreTemp > score:
            score = scoreTemp
            choosedAction = accio 

        return choosedAction


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"

        #Funcio que retorna el maxValue d'un estat. El maximitzador sempre es Pacman, agent zero.
        def maximitzador(gameState,depth,alpha,beta):
          novaProf = depth + 1

          if gameState.isWin() or gameState.isLose() or novaProf == self.depth:
            return self.evaluationFunction(gameState)

          maxim = float('-Inf')

          accions = gameState.getLegalActions(0)

          alphaT = alpha #Ens guardem el valor d'alpha per si s'actualitza

          for accio in accions:
            succesor = gameState.generateSuccessor(0,accio)
            maxim = max(maxim,minimitzador(succesor,novaProf,1,alphaT,beta)) #Agafa el maxim dels minims amb l'alpha actual
            if maxim > beta: #Si maxValue es mes gran que el min best option on path to root...
              return maxim 
            alphaT = max(alphaT,maxim) #Actualitzem alpha (max best option on path to root)
          return maxim

        #Funcio que retorna el minValue d'un estat (Els fantasmes nomes)
        def minimitzador(gameState,depth,agentIndex,alpha,beta):

          minim = float('Inf')

          if gameState.isWin() or gameState.isLose():
            return self.evaluationFunction(gameState)

          accions = gameState.getLegalActions(agentIndex)

          betaT = beta

          for accio in accions:
            succesor = gameState.generateSuccessor(agentIndex,accio)
            if agentIndex == (gameState.getNumAgents() -1): #Si em trobo analitzant l'ultim agent que existeix, el seguent sera pacman. Llavors, haig de cridar el maximitzador
              minim = min(minim,maximitzador(succesor,depth,alpha,betaT))
            else: #Si no, segueixo fent l'agent que vingui a continuacio i per tant es un minimitzador
              minim = min(minim, minimitzador(succesor,depth,agentIndex+1,alpha,betaT))

            if minim < alpha: #Si el minim es mes petit que el max best option...
                return minim
            betaT = min(betaT,minim) #Actualitzo el min best option en cas que aquest nou min sigui mes petit
          return minim

        #Accions necesaries per quan estem al root(Pacman)

        accions = gameState.getLegalActions(0)
        score = float('-Inf')
        choosedAction = None
        beta = float('Inf')
        alpha = float('-Inf')

        for accio in accions:
          succesor = gameState.generateSuccessor(0,accio)
          scoreTemp = minimitzador(succesor,0,1,alpha,beta)

          if scoreTemp > score:
            score = scoreTemp
            choosedAction = accio
          if scoreTemp > beta:
            return choosedAction

          alpha = max(alpha,scoreTemp)
        return choosedAction
        


class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled as choosing uniformly at random from their
          legal moves.
        """
        "*** YOUR CODE HERE ***"
        
        #Funcio que retorna el maxValue d'un estat. El maximitzador sempre es Pacman, agent zero.
        def maximitzador(gameState,depth):
          novaProf = depth + 1

          if gameState.isWin() or gameState.isLose() or novaProf == self.depth:
            return self.evaluationFunction(gameState)

          maxim = float('-Inf')

          accions = gameState.getLegalActions(0)
          for accio in accions:
            succesor = gameState.generateSuccessor(0,accio)
            maxim = max(maxim,probablyLevel(succesor,novaProf,1)) #Agafa el maxValue donat per un agent no-racional (basat en probabilitats)
          return maxim

        #Funcio que retorna el valor d'una accio probabilistica
        def probablyLevel(gameState,depth,agentIndex):
          if gameState.isWin() or gameState.isLose():
            return self.evaluationFunction(gameState)

          accions = gameState.getLegalActions(agentIndex)
          totalValue = 0
          value = 0

          for accio in accions:
            succesor = gameState.generateSuccessor(agentIndex,accio)

            if agentIndex == gameState.getNumAgents() -1:#Si em trobo analitzant l'ultim agent que existeix, el seguent sera pacman. Llavors, haig de cridar el maximitzador
              value = maximitzador(succesor,depth)
            else: #Si no, segueixo fent l'agent que vingui a continuacio (un de no-racional) 
              value = probablyLevel(succesor,depth,agentIndex+1)

            totalValue += value
          if (len(accions) == 0):
            return 0
          return float(totalValue)/float(len(accions)) #Probabilitat

        #Accions necesaries quan estem al Root
        accions = gameState.getLegalActions(0)
        score = float('-Inf')
        choosedAction = None

        for accio in accions:
          succesor = gameState.generateSuccessor(0,accio)
          scoreTemp = probablyLevel(succesor,0,1)
          if scoreTemp > score:
            choosedAction = accio
            score = scoreTemp
        return choosedAction




def betterEvaluationFunction(currentGameState):
    """
      Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
      evaluation function (question 5).

      DESCRIPTION: <He creat una funcio que es basa en 3 puntuacions:
      - La primera te en compte el menjar menjat i el que queda per menjar.
      - La segona i tercera tenen en compte l'estat dels fantasmes i les capsules: si els fantsmes estan espantats, com mes a prop millor, pero no minteressa menjar una capsula (resto puntuacio si em trobo a prop d'una)
      - Si els fantasmes NO estan espantats, com mes lluny d'ells millor, i com mes a prop d'una capsula mes puntuacio afegire. 
      La puntuacio total es la suma d'aquestes 3.
    """
    "*** YOUR CODE HERE ***"

    currentPos = currentGameState.getPacmanPosition() #Posicio actual de Pacman
    currentFood = currentGameState.getFood() #Menjar actual
    currentGhostStates = currentGameState.getGhostStates() #Estat dels fantasmes actuals
    currentScaredTimes = [ghostState.scaredTimer for ghostState in currentGhostStates] #Temps que els hi queda d'espant a cada fantasma

    foodList = currentFood.asList() #Llista del menjar ara

    ghostsPos = [i.getPosition() for i in currentGhostStates] #Llista de posicions dels fantasmes

    distMenjar = [util.manhattanDistance(currentPos,i) for i in foodList] #Llista del menjar ara
    distGhosts = [util.manhattanDistance(currentPos,i) for i in ghostsPos] #llista de les distancies a cada fantasma

    
    capsulesRestants = len(currentGameState.getCapsules()) #Numero de capsules restants a menjar

    tempsRestantEspantats = sum(currentScaredTimes) #Suma del temps de cada fantasma espantat
    sumaGhostDist = sum(distGhosts) #Suma de les distancies a cada fantasma

    commonScore = 0 #Score que s'aplica tant a fantasmes com a Pacman
    scoreScared = 0 #Puntuacio condicionada quan els fantasmes estan espantats
    scoreNonScared = 0 #Puntuacio condicionada quan els fantasmes no estan espantats
    sumFoodToEat = 0 #Quin numero de menjar falta per menjar

    eatenFood = len(currentFood.asList(False)) #Numero de menjar menjat

    if sum(distMenjar) > 0:
      sumFoodToEat = sum(distMenjar) 
      sumFoodToEat = 1.0/sumFoodToEat #Valor condicionat segons menjar menjat/menjar no menjat

    commonScore += currentGameState.getScore() + sumFoodToEat + eatenFood #La primera score vve condicionada per l'score actual, el menjar que falta de menjar i el menjat
      

    #Si els fantasmes estan espantats, com mes aprop millor. Si em trobo aprop d'una capsula, no minteresa menjarla (resto puntacio)
    if tempsRestantEspantats > 0:
      scoreScared += tempsRestantEspantats + (-1*capsulesRestants) + (-1*sumaGhostDist)
    #Si no estan espantats, com mes lluny millor, i com mes a prop d'una capsula millor
    else:
      scoreNonScared += sumaGhostDist + capsulesRestants

    return commonScore + scoreNonScared + scoreScared #Puntuacio total es la suma d'aquestes puntuacions

# Abbreviation
better = betterEvaluationFunction

